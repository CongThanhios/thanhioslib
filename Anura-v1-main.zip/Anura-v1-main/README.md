# Anura GetKey Web

Simple get-key web. Flow: Linkvertise -> user tới `/getkey` -> nhận JSON {key,expires} -> user paste key vào script -> script POST /validate

## Local
1. node >= 18
2. npm install
3. npm start
4. Mở http://localhost:3000

## Deploy từ GitHub
1. Tạo repo trên GitHub.
2. Push toàn bộ thư mục.
3. Kết nối repo với Render / Railway / Heroku.
   - Build command: `npm install`
   - Start command: `npm start`
4. Thiết lập `ADMIN_SECRET` env nếu muốn bật revoke bảo mật.

## Lưu ý bảo mật
- Dùng HTTPS.
- Thêm rate-limit, captcha nếu cần.
- Giữ `keys.json` private. Hoặc đổi sang DB (Mongo/Postgres) khi có nhiều user.
