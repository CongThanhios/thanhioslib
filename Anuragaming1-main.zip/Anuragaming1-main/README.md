<h1 align="center" style="color:#FF66C4">🌐 Hello world, I'am Anura Gaming💫</h1>
<h3 align="center" style="color:#66CCFF">If you need help then message me on Discord</h3>

<p align="center">
  <img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=24&pause=1000&color=FF66C4&center=true&vCenter=true&width=435&lines=Anura+Hub+Roblox+Scripter;Auto+Bounty+Creator;Fluxus+Android+Ready;Follow+for+Updates!" />
</p>

---

### 🎧 I am a fan of Sơn Tùng M-TP 

<p align="center">
  <img src="<img src="https://open.spotify.com/user/313wevh4qwgdvhqg3kjgxidy5a34?si=6962aa5c8435476f"/>
</p>

---

### 📈 GitHub Stats

<p align="center">
  <img src="https://github-readme-stats.vercel.app/api?username=anura123&show_icons=true&theme=tokyonight&title_color=FF66C4&icon_color=66CCFF&text_color=ffffff&bg_color=0d1117" />
</p>

---

### 🔥 My Contributions

<p align="center">
  <img src="https://streak-stats.demolab.com?user=anura123&theme=tokyonight&hide_border=true&ring=FF66C4&fire=66CCFF&currStreakLabel=ffffff" />
</p>

---

### 📲 Connect with Me

<p align="center">
  <a href="https://discord.com/users/1208596199603445801" target="_blank">
    <img src="https://img.shields.io/badge/Discord-FF66C4?style=for-the-badge&logo=discord&logoColor=white" />
  </a>
  <a href="https://www.youtube.com/@Anura-gaming-real" target="_blank">
    <img src="https://img.shields.io/badge/Youtube-66CCFF?style=for-the-badge&logo=youtube&logoColor=white" />
  </a>
  <a href="https://www.tiktok.com/@anurav2.0?_t=ZS-8xF6WiL1Kzf&_r=1" target="_blank">
    <img src="https://img.shields.io/badge/TikTok-FF66C4?style=for-the-badge&logo=tiktok&logoColor=white" />
  </a>
</p>

---

<p align="center" style="color:#888">
  💻 Crafted with <span style="color:#FF66C4">💗</span>Anura Gaming On top</strong>
</p>
