# mấy con chó vô đây skid là ngầu lắm r đó . chưa đủ wow đâu mấy con chó . mày đọc hiểu ko thôi , chứ source ngày xưa cũng lấy thì nhục phải biết
